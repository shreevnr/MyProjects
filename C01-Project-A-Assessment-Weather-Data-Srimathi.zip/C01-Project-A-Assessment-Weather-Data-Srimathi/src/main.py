from model import UserModel, DeviceModel,DailyReportModel,WeatherDataModel
from datetime import datetime

# Shows how to initiate and search in the users collection based on a username

user_coll = UserModel()
device_coll = DeviceModel()
wdata_coll = WeatherDataModel()
print("1.a....Updating User collection with device_id and accesstype details")
# Performing update operation on Usercollection
filter = {'username': 'user_1'}
# Updating User collection with deviceid and accesstype details
data = {'$set': {"alist": [{'did': 'DH003', 'atype': 'rw'}, {'did': 'DH002', 'atype': 'r'}]}}
result = user_coll.single_update(user_coll.USER_COLLECTION, filter, data)
print(result)
print('\n')
filter = {'username': 'user_2'}
# Updating User collection with deviceid and accesstype details
data = {'$set': {"alist": [{'did': 'DT001', 'atype': 'rw'}, {'did': 'DT002', 'atype': 'r'}]}}
result = user_coll.single_update(user_coll.USER_COLLECTION, filter, data)
print(result)
print('\n')
#####Accesing User Collection
####Check whether the user have admin access
print("\n1.a.....Check the user have admin access")
access_user_name = input("Enter the user name\n")
user_query1 = {'username': access_user_name, 'role': 'admin'}
access_document = user_coll.find_single(user_coll.USER_COLLECTION, user_query1)
if access_document:
    print(f"Does the {access_user_name} have admin access?\n True")
else:
    print(f"Does the {access_user_name} have admin access?\n False")
print("\n1.a....Check only admin can retrieve User Collection")
user_query = input('Enter username \n')
role = input('Enter the role to access users\n')
if (role == 'admin'):
    user_document = user_coll.find_by_username(user_query)
    print(user_document)
else:
    print("Admin access required to read user data")
####Adding new user in user_collection
print("\n 1.a...Add new user in UserCollection")
user_role = input('Enter role name to add users\n')
if user_role == 'admin':
    # Shows a successful attempt on how to insert a user
    user_document = user_coll.insert('test_1', 'test_1@example.com', 'default',
                                     [{'did': 'DT004', 'atype': 'r'}, {'did': 'DH005', 'atype': 'rw'}])
    if (user_document == -1):
        print(user_coll.latest_error)
    else:
        print(user_document)
else:
    print(f"Insert failed.Admin access required")

#######################################################################
# Accessing Devices and Weather data with accesstype
# Reading the Device and Weather data details with 'r' or 'rw'
print("\n1.b...Accessing the Devices and Weather Data")
user_name = input("Enter the username\n")
device_id = input("Enter the device id\n")
if (user_name == 'admin'):
    admin_device_fetch = device_coll.find_by_device_id(device_id)
    if (admin_device_fetch):
        print(f"Device data information for {device_id} with only device_id\n")
        print(admin_device_fetch)
        wdata_document = wdata_coll.find_by_device_id(device_id)
        print(f"Weather data information for {device_id} with only device_id\n", wdata_document)
        data_document = wdata_coll.find_by_device_id_and_timestamp(device_id, datetime(2020, 12, 2, 13, 30, 0))
        print(f"Weather data information for {device_id}data with timestamp \n", data_document)

else:
    rw_query_data = {'username': user_name, 'alist': {'did': device_id, 'atype': 'rw'}}
    readwrite = user_coll.find_single(user_coll.USER_COLLECTION, rw_query_data)
    # Shows how to initiate and search in the devices collection based on a device id
    if readwrite:
        device_document = device_coll.find_by_device_id(device_id)
        if (device_document):
            print(f"The user can access{device_id} and the device details are\n", device_document)
            print("Retrieving weather data")
            wdata_document = wdata_coll.find_by_device_id(device_id)
            print(f"Weather data information for {device_id} with only device_id\n", wdata_document)
            data_document = wdata_coll.find_by_device_id_and_timestamp(device_id, datetime(2020, 12, 2, 13, 30, 0))
            print(f"Weather data information for {device_id}data with timestamp \n", data_document)
    else:
        r_query_data = {'username': user_name, 'alist': {'did': device_id, 'atype': 'r'}}
        read = user_coll.find_single(user_coll.USER_COLLECTION, r_query_data)
        # Shows how to initiate and search in the devices collection based on a device id
        if read:
            wdata_document = wdata_coll.find_by_device_id(device_id)
            print(f"Weather data information for {device_id} with only device_id\n", wdata_document)
            device_document = device_coll.find_by_device_id(device_id)
            if (device_document):
                print(f"The user {user_name} has read access for {device_id} and the device information are\n",
                      device_document)
                print("Retrieving weather data")
                wdata_document = wdata_coll.find_by_device_id(device_id)  # retrieving weather data with only device id
                print(f"Weather data information for {device_id} with only device_id\n", wdata_document)
                data_document = wdata_coll.find_by_device_id_and_timestamp(device_id, datetime(2020, 12, 2, 13, 30,))  # retrieving weather data with both device id and time_stamp
                print(f"Weather data information for {device_id}data with timestamp \n", data_document)
        else:
            print(f"Read access not allowed on {device_id}")

######################################################################################################################
# Writing the Device and Weather data details with access admin or 'rw'
print("\n1.a.....Check whether only admin can insert new device")
# print("\nTry adding new device")
add_dev_user_name = input("Enter username to add new device\n")
if (add_dev_user_name == 'admin'):
    # Shows a successful attempt on how to insert a new device
    device_document = device_coll.insert('DT201', 'Temperature Sensor', 'Temperature', 'Acme')
    if (device_document == -1):
        print(device_coll.latest_error)
    else:
        print(device_document)
else:
    print("Admin access required to insert a new device")
######Writing into Weather Data
# Shows how to initiate and search in the weather_data collection based on a device_id and timestamp
print("\n 1.b...Writing to Device data and weather data")
w_username = input("Enter the Username\n")
w_devicename = input("Enter the device name\n")
if (w_username == 'admin'):
    write_filter = {'device_id': w_devicename}
    print(write_filter)
    write_info = {'$set': {'manufacturer': 'acme2'}}
    write_doc = device_coll.single_update(device_coll.DEVICE_COLLECTION, write_filter, write_info)
    if write_doc:
        print(f"The {w_username} successfully write into the device {w_devicename} ")
        print(write_doc.acknowledged)
        print(f"The {w_username} with device {w_devicename} writes to Weather Data Colletion\n")
        wdata_document = wdata_coll.insert(w_devicename, 12, datetime(2020, 7, 2, 13, 30, 0))
        if (wdata_document == -1):
            print(wdata_coll.latest_error)
        else:
            print(wdata_document)
else:
    w_query_data = {'username': w_username, 'alist': {'did': w_devicename, 'atype': 'rw'}}
    write = user_coll.find_single(user_coll.USER_COLLECTION, w_query_data)
    if write:
        print("Enter the query to write")
        write_filter = {'device_id': w_devicename}
        print(write_filter)
        write_info = {'$set': {'manufacturer': 'acme1'}}
        write_doc = device_coll.single_update(device_coll.DEVICE_COLLECTION, write_filter, write_info)
        if write_doc:
            print(f"The {w_username} successfully write into the device {w_devicename} ")
            print(write_doc.acknowledged)
            print(f"The {w_username} with device {w_devicename} writes to Weather Data Colletion\n")
            wdata_document = wdata_coll.insert(w_devicename, 12, datetime(2020, 7, 2, 13, 30, 0))
            if (wdata_document == -1):
                print(wdata_coll.latest_error)
            else:
                print(wdata_document)
    else:
        print(f"The {w_username} doesnt have write access on the device {w_devicename}")


################################################################################
#print("\n Query the Device by device and time stamp and write to device")
# wdata_document = wdata_coll.find_by_device_id_and_timestamp('DT002', datetime(2020, 12, 5, 12, 30, 0))
# if (wdata_document):
# print(wdata_document)
# Shows a failed attempt on how to insert a new data point
# wdata_document = wdata_coll.insert('DT002', 12, datetime(2020, 12, 2, 13, 30, 0))
# if (wdata_document == -1):
#  print(wdata_coll.latest_error)
# else:
#   print(wdata_document)
########################################################################################################
print("\n2.a and 2.b....Aggregate Weather Data and store in Daily Reports Collection")
pl1 = [
       {'$group':
            {'_id':{'device_id':"$device_id",
                    'day': {'$dateToString':
                                {'format': '%Y-%m-%d', 'date': '$timestamp'}
                            }
                    },
                    'Max_Value': {'$max': '$value'},
                    'Min_Value': {'$min': '$value'},
                    'Avg_Value':{'$avg':'$value'}
                     }
        },
     {'$project': {
                'Device_id': '$_id.device_id',
				'Date': '$_id.day',
				'Max_Value': 1,
				'Min_Value': 1,
                'Avg_Value':1,
                '_id':0
                }
     },
    {'$sort':{'Device_id':1,'date':1}},
    {'$out':'Daily Report Data'}

       ]
#{'$group': {device_id: '$device_id', 'Max_Value': {'$max': '$value'}, 'Min_Value': {'$min': '$value'},'Avg_Value': {'$avg': '$value'}}}]
result = wdata_coll.aggregate_data(wdata_coll.WEATHER_DATA_COLLECTION, pl1)
print("New Collection Daily Report Collection created Successfully")
print("\n2.C.....Retrieve Data from Daily Report Collection")
daily_report_coll=DailyReportModel()
ret_device_name=input("Enter the device name :")
ret_data_range=input("Enter the range of days :")
ret_query_data={'Device_id':ret_device_name}
ret_mutiple_day=daily_report_coll.find_multiple(daily_report_coll.DAILY_REPORT_COLLECTION,ret_query_data,ret_data_range)
print("Daily report for multiple days :")
for ret_document in  ret_mutiple_day:
  print(ret_document)
print("\nDaily report for single day :")
ret_single_day=daily_report_coll.find_one(daily_report_coll.DAILY_REPORT_COLLECTION,ret_query_data)
print(ret_single_day)




