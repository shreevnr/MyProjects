# Imports MongoClient for base level access to the local MongoDB
from pymongo import MongoClient


class Database:
    # Class static variables used for database host ip and port information, database name
    # Static variables are referred to by using <class_name>.<variable_name>
    HOST = '127.0.0.1'
    PORT = '27017'
    DB_NAME = 'project_weather_db'

    def __init__(self):
        self._db_conn = MongoClient(f'mongodb://{Database.HOST}:{Database.PORT}')
        self._db = self._db_conn[Database.DB_NAME]

    # This method finds a single document using field information provided in the key parameter
    # It assumes that the key returns a unique document. It returns None if no document is found
    def get_single_data(self, collection, key):
        db_collection = self._db[collection]
        document = db_collection.find_one(key)
        return document

    # This method inserts the data in a new document. It assumes that any uniqueness check is done by the caller
    def insert_single_data(self, collection, data):
        db_collection = self._db[collection]
        document = db_collection.insert_one(data)
        return document.inserted_id

    # This method update the collection with new fields
    def update_one(self, collection, query_data, update_data):
        db_collection = self._db[collection]
        document = db_collection.update_one(query_data, update_data)
        return document

    # This method used to filter and find the data
    def find_one(self, collection, query_data):
        db_collection = self._db[collection]
        document = db_collection.find_one(query_data)
        return document
    #This method used for aggregating weather data
    def aggregate(self, collection, query):
        db_collection = self._db[collection]
        document = db_collection.aggregate(query)
        return document

    #This method finds multiple document
    def find(self, collection, query_data,range):
        db_collection = self._db[collection]
        document = db_collection.find(query_data).limit(int(range))
        return document
