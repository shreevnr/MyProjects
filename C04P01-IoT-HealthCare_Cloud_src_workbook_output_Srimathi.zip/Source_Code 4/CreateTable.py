import boto3
from boto3.dynamodb.conditions import Key
class Table:
    def __init__(self):
        self._dynamodb=boto3.resource('dynamodb')

    def create_table(self, name, pk,sk):
        document = self._dynamodb.create_table(
        TableName=name,
        KeySchema=[
            {'AttributeName': pk,
             'KeyType': 'HASH'},
            {'AttributeName': sk,
             'KeyType': 'RANGE'}
            ],
            AttributeDefinitions =[
        {
            "AttributeName": pk,
            "AttributeType": "S"
        },
        {
            "AttributeName": sk,
            "AttributeType": "S"
        }
    ],
        ProvisionedThroughput={
            # ReadCapacityUnits set to 10 strongly consistent reads per second
            'ReadCapacityUnits': 10,
            'WriteCapacityUnits': 10  # WriteCapacityUnits set to 10 writes per second
        }
    )
        return document
if __name__ == '__main__':
    t=Table()
    raw_data=t.create_table('BSM_DATA','deviceid','timestamp')
    agg_data=t.create_table('BSM_AGG_DATA','deviceid_datatype','timestamp')
    alerts_data=t.create_table('BSM_ALERTS','deviceid_datatype_ruleno','timestamp')
    print("The Tables are successfully created in dynamoDB")

