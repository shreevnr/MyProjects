import boto3
from boto3.dynamodb.conditions import Key,Attr
import statistics
from Database import Database
import itertools
table_name = 'BSM_AGG_DATA'
class AggregateModel:
    def __init__(self):
        self._db_table = Database(table_name)
    def aggregate_data(self,response,device_id,sensortype):
        response={"Items":response}
        print(response)
        print(type(response))
        items_by_minute = itertools.groupby(
            response["Items"],
            key=lambda x: x["timestamp"][:16]  # The first 16 characters including the minute
        )
        # Calculate the Avg,min and max for each minute
        for minute,items in items_by_minute:
            if sensortype in ('HeartRate','SPO2',"Temperature"):
                values_per_minute= [round(float(item["value"])) for item in items]
            elif sensortype=='Temperature':
                values_per_minute = [round(float(item["value"])) for item in items]
            data = {}
            avg=statistics.mean(values_per_minute)
            min_value=min(values_per_minute)
            max_value=max(values_per_minute)
            data['avg'] = str(avg)
            data['min_value'] = str(min_value)
            data['max_value'] = str(max_value)
            data['deviceid_datatype']=device_id+"#"+sensortype
            data['timestamp']=minute
            data['datatype']=sensortype
            #print("Populate Aggregate Data Table")
            self._db_table.insert_single_data(data)
            ##print(response)
    #
    # def aggregate_by_data(self,deviceid,starttime,endtime):
    #     for sensortype in ("Temperature","SPO2","HeartRate"):
    #         self.aggregate_data(deviceid,starttime,endtime)

    def find_all(self):
        response = self._db_table.scan_data()
        return response

