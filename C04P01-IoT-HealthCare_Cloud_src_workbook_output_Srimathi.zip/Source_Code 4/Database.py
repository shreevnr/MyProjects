# Imports boto3
from queue import Empty
import boto3


class Database:
    #######Initiate connection to dynamodb and tables
    def __init__(self, table_name):
        self._dynamodb = boto3.resource('dynamodb')
        self._db_table = self._dynamodb.Table(table_name)
    ########CreateTable

    ########Method get single data
    def get_single_data(self, data):
        document = self._db_table.get_item(key = data)
        return document['Item']
    ########Method to insert single data
    def insert_single_data(self, data):
        self._db_table.put_item(Item = data)
        return True
        #return document

    ########Method to insert many data
    def insert_all(self, data):
        with self._db_table.batch_writer() as batch:
            for i in batch:
                batch.put_item(Item=i)
        return batch

    def delete_single_data(self, data):
        document = self._db_table.delete_item(Item = data)
        return document

    def update_single_data(self, data, updateexp, expresssionattrval) :
        document = self._db_table.update_item(key = data, UpdateExpression = updateexp, ExpressionAttributeValues = expresssionattrval)
        return document['Item']

    def query_data(self,ke,fe):
        document = self._db_table.query(KeyConditionExpression = ke, FilterExpression = fe)
        return document['Items']
    
    def scan_data(self):
        document = self._db_table.scan()
        #print("Scan done")
        return document['Items']


    
    