import boto3
from boto3.dynamodb.conditions import Key
import json
from AggregateModel import AggregateModel
from Database import Database


class AlertDataModel:

    def __init__(self):
        self._db_table = Database('BSM_ALERTS')
    def generate_alert(self,response):
        ####Parsing rule file
        f = open("rules.json")
        rule_data = json.loads(f.read())
        f.close()

        ##Iterating through device and sensor and generate alerts
        for rule in rule_data['rules']:
            max_counter = 0
            min_counter = 0
            for data in response:
                item_max = data['max_value']
                item_min = data['min_value']
                rule_max=rule['max_value']
                rule_min=rule['min_value']
                trigger_counter=rule['trigger_count']
                if data['datatype']==rule['sensor_type']:
                    if item_max > rule_max:
                        max_counter+=1
                        if max_counter==1:
                            breachtime=data['timestamp']

                    else:
                        max_counter=0
                    if item_min < rule_min:
                        min_counter+=1
                        if min_counter == 1:
                            breachtime = data['timestamp']
                    else:
                        min_counter = 0
                    if max_counter == trigger_counter:
                        max_counter == 0
                        print(f"Alert for Device id {data['deviceid_datatype'][:8]} on rule {rule['rule_no']} starting at time {breachtime} with breachtype as max")
                        alert_data = {"deviceid_datatype_ruleno": data['deviceid_datatype'] +"#"+rule['rule_no'],
                                          "sensor": rule['sensor_type'],
                                          "timestamp": breachtime,
                                          "rule_no": rule['rule_no'],
                                          "trigger_count": trigger_counter,
                                          "type":'max'
                                          }
                        self._db_table.insert_single_data(alert_data)
                    elif min_counter == trigger_counter:
                        min_counter == 0
                        print(f"Alert for Device id {data['deviceid_datatype'][:8]} on rule {rule['rule_no']} starting at time {breachtime} with breachtype as min")
                        alert_data = {"deviceid_datatype_ruleno": data['deviceid_datatype'] +"#"+rule['rule_no'],
                                          "sensor": rule['sensor_type'],
                                          "timestamp": breachtime,
                                          "rule_no": rule['rule_no'],
                                          "trigger_count": trigger_counter,
                                          "type":"min"
                                          }
                        self._db_table.insert_single_data(alert_data)







