from RawDataModel import RawDataModel
from AggregateModel import AggregateModel
from CreateTable import Table
from AlertDataModel import AlertDataModel
from datetime import datetime
######Creating Instances for tables
rdm = RawDataModel()
agm = AggregateModel()
alm=AlertDataModel()
print("Aggregate the values of sensors for minute level ")
start_time='25-08-2022 11:49:03'
end_time='25-08-2022 12:49:03'
print(f"The time range to aggregate minute level is {start_time} to {end_time}")
###########Aggregate Data by minutelevel
device_list=['BSM_G101','BSM_G102']
sensor_type_list=['HeartRate','SPO2','Temperature']
for device in device_list:
    for sensor in sensor_type_list:
        query_data=rdm.find(device,sensor,start_time,end_time)
        print(f"Aggregate the Values : Device {device}  and sensor {sensor}")
        agm.aggregate_data(query_data,device,sensor)
# ###############Generate Alerts
print("Generate Alerts for Anamolys")
agg_data=agm.find_all()
alm.generate_alert(agg_data)




