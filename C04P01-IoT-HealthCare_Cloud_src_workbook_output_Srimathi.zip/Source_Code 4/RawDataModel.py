from os import device_encoding
from urllib import response
import boto3
from boto3.dynamodb.conditions import Key, Attr
from Database import Database

table_name='BSM_DATA'

class RawDataModel:

    def __init__(self):
        self._db_table = Database(table_name)

    def find_all(self):
        response=self._db_table.scan_data()
        return response

    def find(self,deviceid,sensortype,startdate,enddate):
        ke=Key('deviceid').eq(deviceid) & Key('timestamp').between(startdate,enddate)
        fe=Attr('sensor_type').eq(sensortype)
        response = self._db_table.query_data(ke,fe)
        #print(response["Items"])
        return response
    def get_data(self,data):
        response=self._db_table.get_single_data(data)
