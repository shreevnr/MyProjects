import json
import hashlib
import base64

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.exceptions import InvalidSignature

from Block import Block


class Blockchain:
    # Basic blockchain init
    # Includes the chain as a list of blocks in order, pending transactions, and known accounts
    # Includes the current value of the hash target. It can be changed at any point to vary the difficulty
    # Also initiates a genesis block
    def __init__(self, hash_target):
        self._chain = []
        self._pending_transactions = []
        self._chain.append(self.__create_genesis_block())
        self._hash_target = hash_target
        self._accounts = {}

    def __str__(self):
        return f"Chain:\n{self._chain}\n\nPending Transactions: {self._pending_transactions}\n"

    @property
    def hash_target(self):
        return self._hash_target

    @hash_target.setter
    def hash_target(self, hash_target):
        self._hash_target = hash_target

    # Creating the genesis block, taking arbitrary previous block hash since there is no previous block
    # Using the famous bitcoin genesis block string here :)  
    def __create_genesis_block(self):
        genesis_block = Block(0, [], 'The Times 03/Jan/2009 Chancellor on brink of second bailout for banks',
                              None, 'Genesis block using same string as bitcoin!')
        return genesis_block

    def __validate_transaction(self, transaction):
        # Serialize transaction data with keys ordered, and then convert to bytes format
        hash_string = json.dumps(transaction['message'], sort_keys=True)
        encoded_hash_string = hash_string.encode('utf-8')

        # Take sha256 hash of the serialized message, and then convert to bytes format
        message_hash = hashlib.sha256(encoded_hash_string).hexdigest()
        encoded_message_hash = message_hash.encode('utf-8')

        # Signature - Encode to bytes and then Base64 Decode to get the original signature format back
        signature = base64.b64decode(transaction['signature'].encode())

        # signature=transaction['signature']

        try:
            # Load the public_key object and verify the signature against the calculated hash
            sender_public_pem = self._accounts.get(transaction['message']['sender']).public_key
            sender_public_key = serialization.load_pem_public_key(sender_public_pem)
            # print("Sender_public_key",sender_public_key)
            sender_public_key.verify(
                signature,
                encoded_message_hash,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
        except InvalidSignature:
            return False

        return True

    def __process_transactions(self, transactions):
        # For all transactions, first check that the sender has enough balance.
        # Appropriately transfer value from the sender to the receiver
        # Return False otherwise

        invalid_transactions=[]
        for transaction in transactions:
            sender = transaction['message']['sender']
            amount = transaction['message']['value']
            receiver = transaction['message']['receiver']
            sender_balance = self._accounts.get(sender).balance
            # #Checking if the sender has enough balance
            if sender_balance < amount:
                print(f"Sender{sender} has insufficient balance.Hence invalid Transaction")
                print(f"Invalid Transaction :{transaction}")
                invalid_transactions.append(transaction)
            else:
                # update the balances of sender and receiver by decreasing and increasing the amount/value
                self._accounts.get(receiver).increase_balance(amount)
                self._accounts.get(sender).decrease_balance(amount)
        # Removing invalid transactions from pending transaction
        for transaction in invalid_transactions:
            self._pending_transactions.remove(transaction)
        if (len(invalid_transactions)!=0):
            return False
        return True

    # Creates a new block and appends to the chain
    # Also clears the pending transactions as they are part of the new block now
    # if invalid transaction exists while processing re mine the block
    def create_new_block(self):
        new_block = Block(len(self._chain), self._pending_transactions, self._chain[-1].block_hash, self._hash_target)
        if not self.__process_transactions(self._pending_transactions):
            if(len(self._pending_transactions) > 0):
                new_block = Block(len(self._chain), self._pending_transactions, self._chain[-1].block_hash,
                                self._hash_target)
            else:
                return False
        self._chain.append(new_block)
        self._pending_transactions = []
        return new_block

    # Simple transaction with just one sender, one receiver, and one value
    # Created by the account and sent to the blockchain instance
    def add_transaction(self, transaction):
        if self.__validate_transaction(transaction):
            self._pending_transactions.append(transaction)
            return True
        else:
            print(f'ERROR: Transaction: {transaction} failed signature validation')
            return False

    def __validate_chain_hash_integrity(self):
        # Run through the whole blockchain and ensure that previous hash is actually the hash of the previous block
        # Return False otherwise
        # start from index one to exclude genesis block for obvious reasons
        for index in range(1, len(self._chain)):
            if (self._chain[index].previous_block_hash != self._chain[index - 1].hash_block()):
                print(f'Previous block hash mismatch in block index: {index}')
                return False
        return True

    def __validate_block_hash_target(self):
        # Run through the whole blockchain and ensure that block hash meets hash target criteria, and is the actual hash of the block
        # Return False otherwise
        for index in range(1, len(self._chain)):
            if (int(self._chain[index].block_hash, 16) > int(self._chain[index].hash_target, 16)):
                print(f'Hash target not achieved in block index: {index}')
                return True
            if (int(self._chain[index].hash_block(), 16) == int(self._chain[index].block_hash, 16)):
                return True

    def __validate_complete_account_balances(self):
        # Run through the whole blockchain and ensure that balances never become negative from any transaction
        # Return False otherwise
        # Check each transaction in each block for each account
        account_balances = {}
        for index in range(1, len(self._chain)):
            transactions = self._chain[index].transactions
            for transaction in transactions:
                amount=transaction['message']['value']
                sender=transaction['message']['sender']
                receiver=transaction['message']['receiver']
                if (sender not in account_balances):
                    account_balances[sender] = self._accounts.get(sender).initial_balance
                if (receiver not in account_balances):
                    account_balances[receiver] = self._accounts.get(receiver).initial_balance

                if (account_balances[sender] < amount) or (account_balances[sender] < 0):
                    print(f"{sender} is transferring more '{amount}' then the current running balance '{account_balances[sender]}'\n")
                    return False
                else:
                    account_balances[sender] -= amount
                    account_balances[receiver] += amount
        return True


    # Blockchain validation function
    # Runs through the whole blockchain and applies appropriate validations
    def validate_blockchain(self):
        # Call __validate_chain_hash_integrity and implement that method. Return False if check fails
        if self.__validate_chain_hash_integrity():
            print("The Previous hash is actually the hash of previous block\n")
        else:
            return False
        # Call __validate_block_hash_target and implement that method. Return False if check fails
        if self.__validate_block_hash_target():
            print("Block hash meets hash target criteria, and is the actual hash of the block\n")
        else:
            return False
        # Call __validate_complete_account_balances and implement that method. Return False if check fails
        if self.__validate_complete_account_balances():
            print("All the accounts have Valid balance to do transactions and are in Complaince\n")
        else:
            return False
        return True

    def add_account(self, account):
        self._accounts[account.id] = account

    def get_account_balances(self):
        return [{'id': account.id, 'balance': account.balance} for account in self._accounts.values()]

    # def get_initial_balance(self):
    #     return [{'id': account.id, 'initial_balance': account.initial_balance} for account in self._accounts.values()]



