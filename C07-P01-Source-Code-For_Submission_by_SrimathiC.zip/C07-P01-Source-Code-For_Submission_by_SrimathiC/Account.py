import hashlib
import json
import base64
import binascii

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.serialization import load_pem_public_key, load_pem_private_key


class Account:
    # Default balance is 100 if not sent during account creation
    # nonce is incremented once every transaction to ensure tx can't be replayed and can be ordered (similar to Ethereum)
    # private and public pem strings should be set inside __generate_key_pair
    def __init__(self, sender_id, balance=100):
        self._id = sender_id
        self._balance = balance
        self._nonce = 0
        self._private_pem = None
        self._public_pem = None
        self.__generate_key_pair()
        self._initial_balance = 100

    @property
    def id(self):
        return self._id

    @property
    def initial_balance(self):
        return self._initial_balance

    @property
    def public_key(self):
        return self._public_pem

    @property
    def balance(self):
        return self._balance

    def increase_balance(self, value):
        self._balance += value

    def decrease_balance(self, value):
        self._balance -= value

    def __generate_key_pair(self):
        # Implement key pair generation logic
        # Convert them to pem format strings and store in the class attributes already defined

        # Generating private and public key pair
        sender_private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        # converting the private key to pem format and storing in the class attributes already defined
        self._private_pem = sender_private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )

        sender_public_key = sender_private_key.public_key()
        # ## converting the public key to pem format and storing in the class attributes already defined
        self._public_pem = sender_public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

    def create_transaction(self, receiver_id, value, tx_metadata=''):
        nonce = self._nonce + 1
        transaction_message = {'sender': self._id, 'receiver': receiver_id, 'value': value, 'tx_metadata': tx_metadata,
                               'nonce': nonce}
        # We convert the transaction details from Dictionary to string format
        # Encoding the string to byte
        # Generating hash of the transaction message
        # Generating private key object from the pem file to sign the transaction
        transaction_to_json = json.dumps(transaction_message, sort_keys=True)
        transaction_to_json_bytes = transaction_to_json.encode('utf-8')
        transaction_hash = hashlib.sha256(transaction_to_json_bytes).hexdigest()

        # sender_private_pem=self._private_pem
        private_key = serialization.load_pem_private_key(self._private_pem, None)

        # print("Key from pem object",sender_private_key)
        # Implement digital signature of the hash of the message
        signature = private_key.sign(
            transaction_hash.encode('utf-8'),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        # convert the signature from ‘bytes’ to an appropriate string based format
        signature = base64.b64encode(signature).decode('utf-8')
        self._nonce = nonce
        # print({'message': transaction_message, 'signature': signature})
        return {'message': transaction_message, 'signature': signature}
