1 Cryptographic Functionalities
1.a
    Have implemented private_key/public_key generation under generate_key_pair method in Account class.
    Assigned the private and public key to private_pem and public_pem respectively,
1.b
    create_transaction method is updated in account class
        private key object is created from the pem created at 1.a
        The transaction message has been successfully hashed.
        Digitally signed the hash with the private key.
        Ensured the appropriate formatting has been applied for hashing and signing inputs.
        Have converted the signature from 'bytes' to appropriate string format using base64 library.
2 Implement Validations

2.a
    Updated process_transactions and create_new_block.
    For each transactions,the balance of sender has been verified whether he has enough balance to make transactions.
    If enough balance,then make appropriate transafer from sender.Both sender and receiver balance will be updated.
    Else add the the transactions to invalid transactions and remove them from pending transactions.
    If invalid transaction exists return false.

    if any invalid transactions exist in pending transaction re mine the block with updated transations in create_new_block.
2.b
    Validate_blockchain

    Implemented _validate_chain_hash_integrity,to ensure that the previous block hash value is actually the previous block's hash value.
    Checked for all blocks excluding Genesis for obvious reasons.

    Implemented _validate_block_hash_target,to ensure that the generated block hash is actually lesser than the target hash
    and is actually the hash of the block with the stored nounce value.Excluded genesis for Obvious reasons.

    Implemented _validate_account_balances,to ensure that all the accounts have had enough balance to do transactions.
    This has been checked for all the blocks in the blockchain to ensure complaince that at no point any account has exceeded
    its balance in any transactions.



