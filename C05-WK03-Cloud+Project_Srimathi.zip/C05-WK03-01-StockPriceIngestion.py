import json
import boto3
import uuid
import sys
import yfinance as yf
from botocore.exceptions import ClientError
import logging
import time
import random
import datetime
import pandas as pd
# Your goal is to get per-hour stock price data for a time range for the ten stocks specified in the doc.
# Further, you should call the static info api for the stocks to get their current 52WeekHigh and 52WeekLow values.
# You should craft individual data records with information about the stockid, price, price timestamp, 52WeekHigh and 52WeekLow values and push them individually on the Kinesis stream
#Modify this line of code according to your requirement.
ec2=boto3.client('ec2',region_name = "us-east-1")
kinesis = boto3.client('kinesis', region_name = "us-east-1")
kinesis_stream = 'ec2_kinesis'
logger = logging.getLogger(__name__)
today=datetime.datetime(2022, 9, 15)
yesterday=datetime.datetime(2022, 9, 14)
#yesterday = datetime.date.today() - datetime.timedelta(3)
# Example of pulling the data between 2 dates from yfinance API
stock_list=["MSFT", "MVIS", "GOOG", "SPOT", "INO", "OCGN", "ABML", "RLLCF", "JNJ", "PSFE"]
## Add code to pull the data for the stocks specified in the doc
for stock in stock_list:
    ##Download stock data
    data = yf.download(stock, start= yesterday, end= today, interval = '1h' )
    ##Download Static Info
    ticker=yf.Ticker(stock)
    ##Construct the data frame with required values
    fiftyTwoWeekHigh=ticker.info['fiftyTwoWeekHigh']
    fiftyTwoWeekLow=ticker.info['fiftyTwoWeekLow']
    data.index.names=['TimeStamp']
    data.reset_index(level=0,inplace=True)
    data['TimeStamp']=data['TimeStamp'].astype(str)
    data['stock_id'] = pd.Series([stock for x in range(len(data.index))], index=data.index)
    data['fiftyTwoWeekHigh']=pd.Series([fiftyTwoWeekHigh for x in range(len(data.index))], index=data.index)
    data['fiftyTwoWeekLow'] = pd.Series([fiftyTwoWeekLow for x in range(len(data.index))], index=data.index)
    ## Reconstructed  dataframe
    data_new_frame=data[['TimeStamp','stock_id','Close','fiftyTwoWeekHigh','fiftyTwoWeekLow']]
    stream_data = data_new_frame.to_dict('records')
    print(stream_data)
    ##Push records to kinesis stream
    for records in stream_data:
        try:
            response = kinesis.put_record(
                StreamName=kinesis_stream,
                Data=json.dumps(records),
                PartitionKey='stock_id')
            logger.info("Put record in stream %s.",kinesis_stream)
            print("Data",json.dumps(records))
        except ClientError:
            logger.exception("Couldn't put record in stream %s.", kinesis_stream)
            raise
        else:
            print(response)





















#     )
