
import json
import time
import paho.mqtt.client as mqtt

HOST = "localhost"
PORT = 1883
WAIT_TIME = 0.25

##Subscribe Topics
REGISTER_DEVICE = "device/register"
REGISTER_DEVICE_MSG= "device/register_status"
DEVICE_STATUS="device/status"
###Publish Topic
REGISTER_STATUS="device/register/response"
#Edge service acts as a bridge/gateway server betweeen user and device
class Edge_Server:
    
    def __init__(self, instance_name):
        
        self._instance_id = instance_name
        self.client = mqtt.Client(self._instance_id)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.connect(HOST, PORT, keepalive=60)
        self.client.loop_start()
        self._registered_list = []
        self._device_type=['light','AC']
        self._room_list=['Living','BR1','BR2']

    # Terminating the MQTT broker and stopping the execution
    def terminate(self):
        self.client.disconnect()
        self.client.loop_stop()

    # Connect method to subscribe to various topics.     
    def _on_connect(self, client, userdata, flags, result_code):
        self.client.subscribe(REGISTER_DEVICE)
        self.client.subscribe(REGISTER_DEVICE_MSG)
        self.client.subscribe(DEVICE_STATUS)


        if result_code != 0:
            print("Egge server is down")

    # method to process the recieved messages and publish them on relevant topics 
    # this method can also be used to take the action based on received commands
    def _on_message(self, client, userdata, msg):
        if msg.topic==REGISTER_DEVICE:
            decode_msg=json.loads(msg.payload)
            print("\n\nRegistration request is received for device {0} in room {1}".format(decode_msg['device_id'],decode_msg['room']))
            print("\nRequest is processed for the device {0} ".format(decode_msg['device_id']))
            device_register_flag=True
            self._registered_list.append(decode_msg['device_id'])
            self.client.publish((REGISTER_STATUS+decode_msg['device_id']),json.dumps(device_register_flag),qos=2)
        elif msg.topic==REGISTER_DEVICE_MSG:
            decode_msg = json.loads(msg.payload)
            print('{0}-Registered Status for device {1} : {2}'.format(decode_msg['msg'],decode_msg['device_id'],decode_msg['registered_status']))
        elif msg.topic==DEVICE_STATUS:
            decode_msg = json.loads(msg.payload)
            print('\nThe Current device status for device {0}:{1} '.format(decode_msg['device_id'],decode_msg))

    # Returning the current registered list
    def get_registered_device_list(self):
        return self._registered_list

    # Getting the status for the connected devices
    def get_status(self,cmd,sub_cmd):
        #Publish the device id Topics
        #print("Publish device topics")
        #####Get Status for Single device
        if cmd=='single':
            #publish_topic="device/"
            if sub_cmd in self._registered_list:
                publish_topic="device/"+sub_cmd+"/"
                #print(publish_topic)
                self.client.publish(publish_topic,"get")
        ####Get Status by device_type
        elif cmd=='device_type':
            if sub_cmd in self._device_type:
                publish_topic = "device/"+sub_cmd+"/"
                #print(publish_topic)
                self.client.publish(publish_topic,"get")
        ####Get Status by room_type
        elif cmd=='room_type':
            if sub_cmd in self._room_list:
                publish_topic = "device/"+sub_cmd +"/"
                #print(publish_topic)
                self.client.publish(publish_topic,"get")
        ####Get Status for entire home
        elif cmd=='home':
            for i in self._registered_list:
                publish_topic = "device/"+i+"/"
                self.client.publish(publish_topic,"get")
                #print(publish_topic)
    # Controlling and performing the operations on the devices
    # based on the request received
    def set(self,cmd,sub_cmd,set_value):
        ####Set/Control Status by single device
        if cmd=='set_single_device':
            if sub_cmd in self._registered_list:
                publish_topic="device/"+sub_cmd+"/"
                #print(publish_topic)
                self.client.publish(publish_topic,set_value)
        ####Set/Control Status by device_type
        elif cmd=='ctrl_device_type':
            if sub_cmd in self._device_type:
                publish_topic="device/"+sub_cmd+"/"
                #print(publish_topic)
                self.client.publish(publish_topic,set_value)
        ####Set/Control Status by room_type
        elif cmd=='ctrl_room_type':
            if sub_cmd in self._room_list:
                publish_topic="device/"+sub_cmd+"/"
                #print(publish_topic)
                self.client.publish(publish_topic,set_value)
        ####Set/Control Status for entire home
        elif cmd == 'ctrl_home':
            for i in self._registered_list:
                publish_topic = "device/" + i + "/"
                self.client.publish(publish_topic,set_value)
                #print(publish_topic)
