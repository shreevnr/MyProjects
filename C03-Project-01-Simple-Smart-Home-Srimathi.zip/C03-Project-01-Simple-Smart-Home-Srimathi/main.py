import time
from EdgeServer import Edge_Server
from LightDevice import Light_Device
from ACDevice import AC_Device

WAIT_TIME = 0.25  

print("\nSmart Home Simulation started.")
# Creating the edge-server for the communication with the user

edge_server_1 = Edge_Server('edge_server_1')
time.sleep(WAIT_TIME)  

# Creating the light_device
print("Intitate the device creation and registration process." )
print("\nCreating the Light devices for their respective rooms.")
light_device_1 = Light_Device("light_1", "Kitchen")
time.sleep(WAIT_TIME)
light_device_2 = Light_Device("light_2", "Living")
time.sleep(WAIT_TIME)
light_device_3 = Light_Device("light_3", "BR1")
time.sleep(WAIT_TIME)
light_device_4 = Light_Device("light_4", "BR2")
time.sleep(WAIT_TIME)

# Creating the ac_device  
print("\n*********************** Creating the AC devices for their respective rooms*********************** ")
ac_device_1 = AC_Device("ac_1", "Living")
time.sleep(WAIT_TIME)
ac_device_2 = AC_Device("ac_2", "BR2")
time.sleep(WAIT_TIME)
ac_device_3 = AC_Device("ac_3", "BR1")
time.sleep(WAIT_TIME)
###################################################################################################
#Registered Device List
print("\n********************** Registered Device Lists on Edge Server***********************")
registered_device=edge_server_1.get_registered_device_list()
print(registered_device)

###################################################################################################
##Perform Status Operations"
print("\n********************** Get  Status of Single Device ***************************")
cmd="single"
for itr in range (0,len(registered_device)):
    print("\nStatus based on Device ID :",registered_device[itr])
    print("Command ID "+str(itr)+" request is Initiated")
    status=edge_server_1.get_status(cmd,registered_device[itr])
    time.sleep(WAIT_TIME)
###################################################################################################
print("\n********************** Get Status by Device_Type *******************************")
print("\nStatus based on Light Device ")
cmd="device_type"
print("\nCommand "+cmd+" is initiated for Light")
status=edge_server_1.get_status(cmd,'light')
time.sleep(WAIT_TIME)
print("Command "+cmd+"is Executed")

print("\nStatus based on AC Device ")
cmd="device_type"
print("\nCommand "+cmd+"is initiated for AC")
status=edge_server_1.get_status(cmd,'AC')
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")
###################################################################################################
print("\n**************************** GetStatus by ROOM TYPE***************************************")
cmd="room_type"
print("\nCommand "+cmd+" is initiated ")
status=edge_server_1.get_status(cmd,'BR1')
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")
print("\nSmart Home Simulation stopped.")

####################################################################################################
print("\n**************************** GetStatus by Entire Home***************************************")
cmd="home"
print("\nCommand "+cmd+" is initiated to get status of Entire home devices")
status=edge_server_1.get_status(cmd,"all_device")
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")

####################################################################################################
print("\n*************************** Set up the Status and Control the device by Device_ID************************")
print("Control device based on Device_id :")
cmd="set_single_device"
print("Command "+cmd+" is initiated to set the status of single device")
status=edge_server_1.set(cmd,"light_1","HIGH")
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")

print("Control device based on Device_id :")
status=edge_server_1.set(cmd,"ac_1",25)
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")
print("\n*************************** Set up the Status and Control the Device_Type************************")
print("Control device based on Device Type")
cmd='ctrl_device_type'
status=edge_server_1.set(cmd,'light','HIGH')
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")
###########################################################################################################################
print("\n*************************** Set up the Status and Control the Device by ROOM************************")
print("Control device based on Room Type")
cmd='ctrl_room_type'
status=edge_server_1.set(cmd,'Living','ON')
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")
###########################################################################################################################
print("\n*************************** Set up the Status and Control the Device For All room ************************")
print("Control device for Entire Home")
cmd='ctrl_home'
#status=edge_server_1.set(cmd,'All','OFF')
#status=edge_server_1.set(cmd,'All','MEDIUM')
status=edge_server_1.set(cmd,'All',27)
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")
##########################################################################################################################
print("\n******************* SETTING UP THE STATUS AND CONTROLLING FOR INVALID REQUESTS *******************")
print("Control AC device with Invalid Value")
cmd='set_single_device'
status=edge_server_1.set(cmd,'ac_1',35)
time.sleep(WAIT_TIME)
print("Control light device with Invalid value")
cmd='set_single_device'
status=edge_server_1.set(cmd,'light_1','hhhh')
time.sleep(WAIT_TIME)
######################################################################################################################
print("\n******************* CURRENT STATUS BEFORE CLOSING THE PROGRAM *******************")
cmd="home"
print("\nCommand "+cmd+" is initiated to get status of Entire home devices")
status=edge_server_1.get_status(cmd,"all_device")
time.sleep(WAIT_TIME)
print("Command "+cmd+" is Executed")
######################################################################################################################
print("\nSmart Home Simulation stopped.")
edge_server_1.terminate()