
import json
import paho.mqtt.client as mqtt


HOST = "localhost"
PORT = 1883

REGISTER_DEVICE="device/register"
REGISTER_DEVICE_MSG= "device/register_status"
REGISTER_STATUS="device/register/response"
###Subscribing topics
DEVICE_TOPIC="device/"
DEVICE_STATUS="device/status"
AC_DEVICES = "device/AC/"
ROOM_TOPIC="device/"

    
class AC_Device():
    
    _MIN_TEMP = 18  
    _MAX_TEMP = 32

    def __init__(self, device_id, room):
        
        self._device_id = device_id
        self._room_type = room
        self._temperature = 22
        self._device_type = "AC"
        self._device_registration_flag = False
        self.client = mqtt.Client(self._device_id)  
        self.client.on_connect = self._on_connect  
        self.client.on_message = self._on_message  
#        self.client.on_disconnect = self._on_disconnect
        self.client.connect(HOST, PORT, keepalive=60)
        self.client.loop_start()  
        self._register_device(self._device_id, self._room_type, self._device_type)
        self._switch_status = "OFF"
        #self._DEVICE_TOPIC = "device/"+self._device_id+"/"
        #self._ROOM_TOPIC="device/"+self._room_type+"/"

    # calling registration method to register the device
    def _register_device(self, device_id, room_type, device_type):
        while not self.client.is_connected():
            pass
        ac_device = {}
        ac_device['device_id'] = device_id
        ac_device['room'] = room_type
        ac_device['device_type'] = device_type
        self.client.publish(REGISTER_DEVICE, json.dumps(ac_device))

    # Connect method to subscribe to various topics. 
    def _on_connect(self, client, userdata, flags, result_code):
        if result_code == 0:
            while not self.client.is_connected():
                pass
            self.client.subscribe(REGISTER_STATUS + self._device_id)
            self.client.subscribe(DEVICE_TOPIC+self._device_id+"/")
            self.client.subscribe(ROOM_TOPIC + self._room_type + "/")
            self.client.subscribe(AC_DEVICES)
    # method to process the recieved messages and publish them on relevant topics 
    # this method can also be used to take the action based on received commands
    def _on_message(self, client, userdata, msg):
        decode_msg = (msg.payload.decode("utf-8")).split(',')
        if msg.topic==(REGISTER_STATUS+self._device_id):
            self._device_registration_flag=True
            ac_device_register={}
            ac_device_register['device_id']=self._device_id
            ac_device_register['registered_status']=self._device_registration_flag
            ac_device_register['msg']='AC Device is Successfully Registered'
            self.client.publish(REGISTER_DEVICE_MSG,json.dumps(ac_device_register))
        elif msg.topic in (DEVICE_TOPIC+self._device_id+"/",AC_DEVICES,ROOM_TOPIC + self._room_type + "/"):
            if decode_msg[0] == "get":
                pass
            elif decode_msg[0] in ("ON","OFF"):
                #print("Message of topic set single device")
                self._set_switch_status(decode_msg[0])
            elif type(decode_msg[0] ==int):
                #print("Set Temperature",type(decode_msg[0] ==int))
                if self._switch_status !='ON':
                    self._set_switch_status('ON')
                self._set_temperature(decode_msg[0])

            ##Create Payload to publish the status of the Devices
            ac_device_status={}
            ac_device_status['device_id']=self._device_id
            ac_device_status['switch_state']=self._get_switch_status()
            ac_device_status['Temperature']=self._get_temperature()
            self.client.publish(DEVICE_STATUS,json.dumps(ac_device_status))

    # Getting the current switch status of devices 
    def _get_switch_status(self):
        return self._switch_status

    # Setting the the switch of devices
    def _set_switch_status(self, switch_state):
        self._switch_status=switch_state

    # Getting the temperature for the devices
    def _get_temperature(self):
        return self._temperature

    # Setting up the temperature of the devices
    def _set_temperature(self, temperature):
        if temperature.isnumeric() and self._MIN_TEMP <= int(temperature) <=self._MAX_TEMP:
            self._temperature=int(temperature)
        elif temperature.isalpha():
            pass
        else:
            print("Temperature Change Failed!..Invalid Temperature Value is received")



    
